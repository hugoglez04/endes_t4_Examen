/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package endes_t4_examen_gonzalez_reguero_hugo;
import java.util.ArrayList;
import java.util.List;

 /**
 * Esta clase representa un cliente de un banco, con su información básica y sus cuentas bancarias asociadas.
 */
public class Cliente {
    private String nombre; // Nombre del cliente
    private String apellido; // Apellido del cliente
    private String id; // Identificación del cliente
    private List<CuentaBancaria> cuentas; // Lista de cuentas bancarias del cliente

    /**
     * Constructor para crear un nuevo cliente con nombre, apellido e identificación.
     * @param nombre El nombre del cliente.
     * @param apellido El apellido del cliente.
     * @param id La identificación del cliente.
     */
    public Cliente(String nombre, String apellido, String id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.id = id;
        this.cuentas = new ArrayList<>(); // Se inicializa la lista de cuentas bancarias.
    }

    /**
     * Método para obtener el nombre del cliente.
     * @return El nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método para establecer el nombre del cliente.
     * @param nombre El nuevo nombre del cliente.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método para obtener el apellido del cliente.
     * @return El apellido del cliente.
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Método para establecer el apellido del cliente.
     * @param apellido El nuevo apellido del cliente.
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * Método para obtener la identificación del cliente.
     * @return La identificación del cliente.
     */
    public String getId() {
        return id;
    }

    /**
     * Método para establecer la identificación del cliente.
     * @param id La nueva identificación del cliente.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Método para obtener una copia de la lista de cuentas bancarias del cliente.
     * @return Una copia de la lista de cuentas bancarias del cliente.
     */
    public List<CuentaBancaria> getCuentas() {
        return new ArrayList<>(cuentas);
    }

    /**
     * Método para agregar una nueva cuenta bancaria al cliente.
     * @param cuenta La cuenta bancaria que se va a agregar.
     */
    public void agregarCuenta(CuentaBancaria cuenta) {
        cuentas.add(cuenta);
    }

    /**
     * Método para cerrar una cuenta bancaria del cliente dado su número de cuenta.
     * @param numeroCuenta El número de la cuenta bancaria que se desea cerrar.
     * @return true si la cuenta se cerró con éxito, false si no se encontró la cuenta.
     */
    public boolean cerrarCuenta(String numeroCuenta) {
        return cuentas.removeIf(cuenta -> cuenta.getNumeroCuenta().equals(numeroCuenta));
    }

    /**
     * Método para obtener una representación en cadena del cliente, incluyendo su nombre, apellido, identificación y cuentas bancarias.
     * @return Una cadena que representa al cliente.
     */
    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", id='" + id + '\'' +
                ", cuentas=" + cuentas +
                '}';
    }
}