/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package endes_t4_examen_gonzalez_reguero_hugo;


/** esta clase corresponde a la cuenta bancaria */
 public class CuentaBancaria {
/** es el numero de la cuenta bancaria */
    private String numeroCuenta;
/** saldo actual de la cuenta */    
    private double saldo;
/** Propietario de la cuenta bancaria */  
    private Cliente propietario;
    
    /**
     * Constructor para crear una instancia de CuentaBancaria.
     * @param numeroCuenta El número de cuenta.
     * @param saldo El saldo inicial.
     * @param propietario El propietario de la cuenta.
     */
    public CuentaBancaria(String numeroCuenta, double saldo, Cliente propietario) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.propietario = propietario;
    }
    
     /**
     * Obtiene el número de cuenta.
     * @return El número de cuenta.
     */    
    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    
    /**
     * Establece el número de cuenta.
     * @param numeroCuenta El nuevo número de cuenta.
     */   
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    /**
     * Obtiene el saldo actual de la cuenta.
     * @return El saldo actual.
     */
    
    public double getSaldo() {
        return saldo;
    }

    /**
     * Establece el saldo de la cuenta.
     * @param saldo El nuevo saldo.
     */
    
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
 /**
     * Obtiene el propietario de la cuenta.
     * @return El propietario de la cuenta.
     */
    public Cliente getPropietario() {
        return propietario;
    }

    /**
     * Establece el propietario de la cuenta.
     * @param propietario El nuevo propietario.
     */
    public void setPropietario(Cliente propietario) {
        this.propietario = propietario;
    }

    /**
     * Deposita una cantidad en la cuenta.
     * @param cantidad La cantidad a depositar.
     */
    public void depositar(double cantidad) {
        saldo += cantidad;
    }

    /**
     * Retira una cantidad de la cuenta, si es posible.
     * @param cantidad La cantidad a retirar.
     * @return true si la operación fue exitosa, false si no hay suficiente saldo.
     */
    public boolean retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
            return true;
        }
        return false;
    }

    /**
     * Devuelve una representación en formato de cadena de la cuenta bancaria.
     * @return Una cadena que representa la cuenta bancaria.
     */
    @Override
    public String toString() {
        return "CuentaBancaria{" +
                "numeroCuenta='" + numeroCuenta + '\'' +
                ", saldo=" + saldo +
                ", propietario=" + propietario.getNombre() + " " + propietario.getApellido() +
                '}';
    }
}
   

