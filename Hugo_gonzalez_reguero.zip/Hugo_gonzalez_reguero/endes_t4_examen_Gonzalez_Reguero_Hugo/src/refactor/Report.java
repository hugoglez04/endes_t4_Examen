/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refactor;

/*
Extraer la impresión del título y conclusión en sus propios métodos.
 */
class Report {

    void printReport() {
        printTitle(); // Llamada al método para imprimir el título

        // contenido del reporte
        System.out.println("Contenido 1...");
        System.out.println("Contenido 2...");

        printConclusion(); // Llamada al método para imprimir la conclusión
    }

    // Método para imprimir el título del reporte
    private void printTitle() {
        System.out.println("Título del Reporte");
    }

    // Método para imprimir la conclusión del reporte
    private void printConclusion() {
        System.out.println("Conclusión del Reporte");
    }
}
