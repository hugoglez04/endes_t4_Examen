/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refactor;

/*
 * Utiliza nombres más descriptvos para las variables.
 */

public class DistanceCalculator {

    // Método para calcular la distancia entre dos puntos en un plano cartesiano
    public double calculateDistance(double x, double y) {
        return x * y;
    }

}
